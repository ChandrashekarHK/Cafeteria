package com.cafeteria;

import com.cafeteria.auth.AuthService;
import com.cafeteria.auth.User;
import com.cafeteria.db.DBOperationsHandler;
import com.cafeteria.userOperations.AdminOperationsHandler;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;

public class CafeteriaServer {
    private static final int PORT = 12345;
    private static DBOperationsHandler dbHandler;
    static User user = new User();
    static AuthService authService;

    static {
        try {
            authService = new AuthService();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public CafeteriaServer() throws SQLException {
    }

    public static void main(String[] args)
    {
        try {
            dbHandler = new DBOperationsHandler();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        System.out.println("Cafeteria Server is running...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                     PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

                    out.println("Welcome to Cafeteria!");

                    // Read user input for authentication
                    String username= in.readLine();
                    user.setUserName(username);
                    String password = in.readLine();
                    user.setPassword(password);
                    String role = in.readLine();
                    user.setRole(role);

                    boolean isValidUser = authService.login(user);
                    if (isValidUser) {
                        out.println("Login successful for role: " + role);
                        if ("admin".equalsIgnoreCase(role)) {
//                            AdminOperationsHandler adminHandler = new AdminOperationsHandler();
//                            adminHandler.start();
                        } else {
                            out.println("Operation for other roles not implemented.");
                        }
                    } else {
                        out.println("Invalid username, password, or role.");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

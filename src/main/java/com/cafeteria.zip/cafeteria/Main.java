package com.cafeteria;

import com.cafeteria.auth.AuthService;
import com.cafeteria.auth.User;
import com.cafeteria.auth.UserInputHandler;
import com.cafeteria.db.DBOperationsHandler;
import com.cafeteria.db.DatabaseConnector;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;


public class Main {
    public static void main(String[] args) throws IOException, SQLException {

        UserInputHandler userInputHandler = UserInputHandler.getInstance();
        User user = userInputHandler.getUserInput();
       // DBOperationsHandler dbOperationsHandler = new DBOperationsHandler();

       AuthService authService = new AuthService();

        if (authService.login(user)) {
            System.out.println("Login successful for role: " + user.getRole());
        } else {
            System.out.println("Invalid username, password, or role.");
        }
        if(user.getRole().equals("Admin")){


        }
    }

}

package com.cafeteria.auth;

import com.cafeteria.utils.ScannerUtil;

import java.io.IOException;

public class UserInputHandler {

    private static UserInputHandler instance;

    public static UserInputHandler getInstance() {
        if (instance == null) {
            synchronized (UserInputHandler.class) {
                if (instance == null) {
                    instance = new UserInputHandler();
                }
            }
        }
        return instance;
    }

    public User getUserInput() {
        IOException lastException = null;

        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                String username = ScannerUtil.scanString("Enter username: ");
                String password = ScannerUtil.scanString("Enter password: ");
                String role = ScannerUtil.scanString("Enter role (admin, chef, employee): ");

                User user = new User();
                user.setUserName(username);
                user.setPassword(password);
                user.setRole(role);

                return user;
            } catch (IOException e) {
                lastException = e;
                System.out.println("Error reading input. Please try again.");
            }
        }

        // If all attempts fail, handle the last exception and return null or throw it
        if (lastException != null) {
            System.out.println("you have completed all the 3 attempts");
            lastException.printStackTrace(); // Print stack trace for debugging purposes
        }
        return null; // or throw a custom exception if required
    }
}

package com.cafeteria.auth;

import com.cafeteria.db.DBOperationsHandler;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AuthService {

    private static DBOperationsHandler dbOperationsHandler;

    public AuthService() throws SQLException {
        this.dbOperationsHandler = new DBOperationsHandler();
    }

    public static boolean login(User user) {
        String query = "SELECT * FROM Users WHERE name = ? AND password = ? AND role = ?";
        ResultSet resultSet = null;

        try {
            resultSet = dbOperationsHandler.executeQuery(query, user.getUserName(), user.getPassword(), user.getRole());

            return resultSet != null && resultSet.next();
        } catch (SQLException e) {

            e.printStackTrace();
            return false;
        } finally {

            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

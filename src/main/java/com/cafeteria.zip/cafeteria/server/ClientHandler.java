package com.cafeteria.server;

import com.cafeteria.auth.AuthService;
import com.cafeteria.auth.User;
import com.cafeteria.userOperations.AdminOperationsHandler;
import com.cafeteria.userOperations.ChefOperationsHandler;
import com.cafeteria.userOperations.EmployeeOperationsHandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.SQLException;

public class ClientHandler implements Runnable {
    private Socket clientSocket;
    private BufferedReader in;
    private PrintWriter out;
    private static AuthService authService;

    static {
        try {
            authService = new AuthService();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            out = new PrintWriter(clientSocket.getOutputStream(), true);

            writeToClient("Welcome to Cafeteria!");

            // Read username and password for authentication
            writeToClient("Enter username:");
            String username = readFromClient();
            writeToClient("Enter password:");
            String password = readFromClient();
            writeToClient("Enter Role:");
            String role = readFromClient();
            User user = new User();
            user.setUserName(username);
            user.setPassword(password);
            user.setRole(role);

            boolean isValidUser = authService.login(user);
            if (isValidUser) {
                writeToClient("Login successful!");

                if ("admin".equalsIgnoreCase(role)) {
                    performAdminOperations();
                }
                else if ("chef".equalsIgnoreCase(role))
                {
                  performChefOperations();
                }
                else if("Employee".equalsIgnoreCase(role))
                {
                    performEmployeeOperations(user);
                }
                else
                {
                    writeToClient("Operation for other roles not implemented.");
                }
            }
            else
            {
                writeToClient("Invalid username or password.");
            }
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null) in.close();
                if (out != null) out.close();
                if (clientSocket != null) clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void performAdminOperations() throws IOException, SQLException {
        AdminOperationsHandler adminHandler = new AdminOperationsHandler(this);
        adminHandler.start();

    }
    private void performChefOperations() throws IOException, SQLException {
        ChefOperationsHandler chefHandler = new ChefOperationsHandler(this);
        chefHandler.start();
    }
    private void performEmployeeOperations(User user) throws IOException, SQLException {
        EmployeeOperationsHandler employeenHandler = new EmployeeOperationsHandler(this,user);
        employeenHandler.start();

    }

    public String readFromClient() throws IOException {
        return in.readLine();
    }

    public void writeToClient(String message) {
        out.println(message);
    }
}

package com.cafeteria.server;

//import com.cafeteria.db.DBOperationsHandler;

public class CafeteriaServer {
    //private static DBOperationsHandler dbHandler;

    public static void main(String[] args) {
        try {

            ServerSocketHandler serverSocketHandler = new ServerSocketHandler();
            serverSocketHandler.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

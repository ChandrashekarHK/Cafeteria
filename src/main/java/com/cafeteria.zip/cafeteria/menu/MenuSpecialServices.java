package com.cafeteria.menu;

import com.cafeteria.db.DBOperationsHandler;

import java.sql.ResultSet;

public class MenuSpecialServices {

    private DBOperationsHandler dbOperationsHandler;

    public MenuSpecialServices(DBOperationsHandler dbOperationsHandler) {
        this.dbOperationsHandler = dbOperationsHandler;
    }

    public ResultSet addMenuItem(MenuItem item) {
        String query = "INSERT INTO MenuItems (foodItemId, name, price, availability) VALUES (?, ?, ?, ?)";
        return dbOperationsHandler.executeQuery(query, item.getId(),item.getName(), item.getPrice(), item.getAvailability());
    }

    public ResultSet updateMenuItem(MenuItem item) {
        String query = "UPDATE MenuItems SET name = ?,availability = ?, price = ? WHERE foodItemId = ?";
        return dbOperationsHandler.executeQuery(query, item.getName(), item.getAvailability(), item.getPrice(), item.getId());
    }

    public ResultSet deleteMenuItem(int id) {
        String query = "DELETE FROM MenuItems WHERE foodItemId = ?";
        return dbOperationsHandler.executeQuery(query, id);
    }
}

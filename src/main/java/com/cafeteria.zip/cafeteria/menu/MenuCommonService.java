package com.cafeteria.menu;

import com.cafeteria.db.DBOperationsHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuCommonService {
    private DBOperationsHandler dbOperationsHandler;

    public MenuCommonService() throws SQLException {
        this.dbOperationsHandler = new DBOperationsHandler();
    }

    public List<MenuItem> getMenu() {
        String query = "SELECT * FROM MenuItems";
        ResultSet resultSet = dbOperationsHandler.executeQuery(query);
        List<MenuItem> menu = new ArrayList<>();
        try {
            while (resultSet != null && resultSet.next()) {
                MenuItem item = new MenuItem(
                        resultSet.getInt("foodItemId"),
                        resultSet.getString("name"),
                        resultSet.getBigDecimal("price"),
                        resultSet.getBoolean("availability")

                );
                menu.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return menu;
    }
}
